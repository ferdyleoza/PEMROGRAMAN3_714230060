module.exports = {
    plugins: {
        tailwindcss: {},
    },
};